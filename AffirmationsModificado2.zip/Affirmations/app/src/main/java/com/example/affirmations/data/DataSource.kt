package com.example.affirmations.data
import com.example.affirmations.R
import com.example.affirmations.model.Affirmation

class Datasource() {

    fun loadAffirmations(): List<Affirmation> {
        return listOf<Affirmation>(
            Affirmation(R.string.affirmation1, "https://github.com/AstridGlauser3/Parte2/blob/main/gat10.jpg?raw=true"),
            Affirmation(R.string.affirmation2, "https://github.com/AstridGlauser3/Parte2/blob/main/gat3.jpg?raw=true"),
            Affirmation(R.string.affirmation3, "https://github.com/AstridGlauser3/Parte2/blob/main/gat4.jpg?raw=true"),
            Affirmation(R.string.affirmation4, "https://github.com/AstridGlauser3/Parte2/blob/main/gat6.jpg?raw=true"),
            Affirmation(R.string.affirmation5, "https://github.com/AstridGlauser3/Parte2/blob/main/gat7.jpg?raw=true"),
            Affirmation(R.string.affirmation6, "https://github.com/AstridGlauser3/Parte2/blob/main/gat8.jpg?raw=true"),
            Affirmation(R.string.affirmation7, "https://github.com/AstridGlauser3/Parte2/blob/main/gat9.jpg?raw=true"),
            Affirmation(R.string.affirmation8, "https://github.com/AstridGlauser3/Parte2/blob/main/gato1.png?raw=true"),
            Affirmation(R.string.affirmation9, "https://github.com/AstridGlauser3/Parte2/blob/main/gato2.jpeg?raw=true"),
            Affirmation(R.string.affirmation10, "https://github.com/AstridGlauser3/Parte2/blob/main/gato5.jpg?raw=true")
        )
    }
}